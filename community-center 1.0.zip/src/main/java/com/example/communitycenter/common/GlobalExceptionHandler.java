package com.example.communitycenter.common;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.communitycenter.resident.DuplicatePhoneException;
import com.example.communitycenter.resident.ResidentNotFoundException;

@RestControllerAdvice
public class GlobalExceptionHandler {

    // 입력값 검증 실패
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationException(
            MethodArgumentNotValidException exception) {

        Map<String, String> errors = new LinkedHashMap<>();

        for (FieldError fieldError
                : exception.getBindingResult().getFieldErrors()) {

            errors.put(
                    fieldError.getField(),
                    fieldError.getDefaultMessage()
            );
        }

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(errors);
    }

    // 존재하지 않는 주민 조회
    @ExceptionHandler(ResidentNotFoundException.class)
    public ResponseEntity<Map<String, String>> handleResidentNotFoundException(
            ResidentNotFoundException exception) {

        Map<String, String> error = new LinkedHashMap<>();

        error.put("message", exception.getMessage());

        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(error);
    }

    // 전화번호 중복 등록
    @ExceptionHandler(DuplicatePhoneException.class)
    public ResponseEntity<Map<String, String>> handleDuplicatePhoneException(
            DuplicatePhoneException exception) {

        Map<String, String> error = new LinkedHashMap<>();

        error.put("message", exception.getMessage());

        return ResponseEntity
                .status(HttpStatus.CONFLICT)
                .body(error);
    }
}