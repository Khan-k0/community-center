package com.example.communitycenter.resident;

public class ResidentNotFoundException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ResidentNotFoundException(Long id) {
        super("주민을 찾을 수 없습니다. id: " + id);
    }
}