package com.example.communitycenter.resident;

import java.time.LocalDateTime;

public class ResidentResponse {

    private Long id;
    private String name;
    private String phone;
    private String address;

    // 추가
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public ResidentResponse(
            Long id,
            String name,
            String phone,
            String address,
            LocalDateTime createdAt,
            LocalDateTime updatedAt) {

        this.id = id;
        this.name = name;
        this.phone = phone;
        this.address = address;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    // 추가
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    // 추가
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
}