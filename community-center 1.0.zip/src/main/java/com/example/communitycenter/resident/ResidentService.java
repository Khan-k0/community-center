package com.example.communitycenter.resident;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class ResidentService {

    private final ResidentRepository residentRepository;

    public ResidentService(ResidentRepository residentRepository) {
        this.residentRepository = residentRepository;
    }

    // 주민 등록
    public ResidentResponse createResident(ResidentCreateRequest request) {
    	
    	String phone = request.getPhone().trim();

        // 이미 같은 전화번호가 존재하면 등록 중단
        if (residentRepository.existsByPhone(phone)) {
            throw new DuplicatePhoneException(phone);
        }
    	
        Resident resident = new Resident();

        resident.setName(request.getName());
        resident.setPhone(request.getPhone());
        resident.setAddress(request.getAddress());

        Resident savedResident = residentRepository.save(resident);

        return toResponse(savedResident);
    }

    // 주민 전체 조회
    public List<ResidentResponse> getResidents() {

        List<Resident> residents = residentRepository.findAll();

        System.out.println("전체 주민 수 = " + residents.size());

        return residents.stream()
                .map(this::toResponse)
                .toList();
    }
    
    
    // 주민 페이징 및 정렬 조회
    public Page<ResidentResponse> getResidentsByPage(
            int page,
            int size,
            String sortBy,
            String direction) {

        Sort sort;

        if ("desc".equalsIgnoreCase(direction)) {
            sort = Sort.by(sortBy).descending();
        } else {
            sort = Sort.by(sortBy).ascending();
        }

        Pageable pageable = PageRequest.of(page, size, sort);

        return residentRepository.findAll(pageable)
                .map(this::toResponse);
    }
    
    
    
    // 주민 통합 조회: 검색 + 페이징 + 정렬
    public Page<ResidentResponse> getResidentList(
            String name,
            int page,
            int size,
            String sortBy,
            String direction) {

        Sort sort;

        if ("desc".equalsIgnoreCase(direction)) {
            sort = Sort.by(sortBy).descending();
        } else {
            sort = Sort.by(sortBy).ascending();
        }

        Pageable pageable = PageRequest.of(page, size, sort);

        if (name == null || name.trim().isEmpty()) {
            return residentRepository.findAll(pageable)
                    .map(this::toResponse);
        }

        String keyword = name.trim();

        return residentRepository
                .findByNameContaining(keyword, pageable)
                .map(this::toResponse);
    }
    

    // 주민 이름 검색
    public List<ResidentResponse> searchResidents(String name) {

        System.out.println("===== ResidentService 검색 시작 =====");
        System.out.println("Service가 전달받은 원본 검색어 = [" + name + "]");

        // 검색어가 null인 경우
        if (name == null) {
            System.out.println("검색어가 null이므로 빈 목록을 반환합니다.");
            return List.of();
        }

        // 검색어 앞뒤 공백 제거
        String keyword = name.trim();

        System.out.println("공백 제거 후 검색어 = [" + keyword + "]");

        // 검색어가 빈 문자열인 경우
        if (keyword.isEmpty()) {
            System.out.println("검색어가 비어 있으므로 빈 목록을 반환합니다.");
            return List.of();
        }

        // 이름에 검색어가 포함된 주민만 조회
        List<Resident> residents =
                residentRepository.findByNameContaining(keyword);

        System.out.println("Repository 검색 결과 개수 = " + residents.size());

        for (Resident resident : residents) {
            System.out.println(
                    "검색 결과 주민 = "
                            + resident.getId()
                            + " / "
                            + resident.getName()
            );
        }

        List<ResidentResponse> responses = residents.stream()
                .map(this::toResponse)
                .toList();

        System.out.println("Response DTO 개수 = " + responses.size());
        System.out.println("===== ResidentService 검색 종료 =====");

        return responses;
    }

    // 주민 한 명 조회
    public ResidentResponse getResident(Long id) {

        Resident resident = findResidentById(id);

        return toResponse(resident);
    }

    // 주민 정보 수정
    public ResidentResponse updateResident(
            Long id,
            ResidentUpdateRequest request) {

        Resident resident = findResidentById(id);

        resident.setName(request.getName());
        resident.setPhone(request.getPhone());
        resident.setAddress(request.getAddress());

        Resident updatedResident = residentRepository.save(resident);

        return toResponse(updatedResident);
    }

    // 주민 삭제
    public void deleteResident(Long id) {

        Resident resident = findResidentById(id);

        residentRepository.delete(resident);
    }

    // ID를 기준으로 주민 찾기
    private Resident findResidentById(Long id) {

        return residentRepository.findById(id)
                .orElseThrow(() -> new ResidentNotFoundException(id));
    }

    // Entity를 Response DTO로 변환
    private ResidentResponse toResponse(Resident resident) {

        return new ResidentResponse(
                resident.getId(),
                resident.getName(),
                resident.getPhone(),
                resident.getAddress(),
                resident.getCreatedAt(),
                resident.getUpdatedAt()
        );
    }
}