package com.example.communitycenter.resident;

public class DuplicatePhoneException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public DuplicatePhoneException(String phone) {
        super("이미 등록된 전화번호입니다. phone: " + phone);
    }
}