package com.example.communitycenter.resident;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResidentRepository
        extends JpaRepository<Resident, Long> {

    // 기존 이름 검색
    List<Resident> findByNameContaining(String name);

    // 이름 검색 + 페이징 + 정렬
    Page<Resident> findByNameContaining(
            String name,
            Pageable pageable
    );
    
    // 전화번호 중복 여부 확인
    boolean existsByPhone(String phone);
}