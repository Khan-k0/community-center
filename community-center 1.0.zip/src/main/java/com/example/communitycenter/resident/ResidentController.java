package com.example.communitycenter.resident;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import jakarta.validation.Valid;

import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.communitycenter.common.ApiResponse;

@RestController
@RequestMapping("/api/residents")
public class ResidentController {

    private final ResidentService residentService;

    // 검색 요청이 몇 번째인지 구분하기 위한 번호
    private final AtomicLong searchRequestCount = new AtomicLong();

    public ResidentController(ResidentService residentService) {
        this.residentService = residentService;
    }

    // 주민 등록
    @PostMapping
    public ApiResponse<ResidentResponse> createResident(
            @Valid @RequestBody ResidentCreateRequest request) {

        ResidentResponse resident =
                residentService.createResident(request);

        return new ApiResponse<>(
                true,
                "주민 등록 성공",
                resident
        );
    }

    // 주민 전체 조회
    @GetMapping
    public ApiResponse<List<ResidentResponse>> getResidents() {

        List<ResidentResponse> residents =
                residentService.getResidents();

        return new ApiResponse<>(
                true,
                "주민 목록 조회 성공",
                residents
        );
    }
    
    // 주민 페이징 및 정렬 조회
    @GetMapping("/page")
    public ApiResponse<Page<ResidentResponse>> getResidentsByPage(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String direction) {

        Page<ResidentResponse> residents =
                residentService.getResidentsByPage(
                        page,
                        size,
                        sortBy,
                        direction
                );

        return new ApiResponse<>(
                true,
                "주민 페이징 조회 성공",
                residents
        );
    }
    
    
    // 주민 통합 조회: 검색 + 페이징 + 정렬
    @GetMapping("/list")
    public ApiResponse<Page<ResidentResponse>> getResidentList(
            @RequestParam(required = false) String name,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String direction) {

        Page<ResidentResponse> residents =
                residentService.getResidentList(
                        name,
                        page,
                        size,
                        sortBy,
                        direction
                );

        return new ApiResponse<>(
                true,
                "주민 통합 조회 성공",
                residents
        );
    }    

    // 주민 이름 검색
    @GetMapping("/search")
    public ApiResponse<List<ResidentResponse>> searchResidents(
            @RequestParam(name = "name", required = false) String name) {

        long requestNumber = searchRequestCount.incrementAndGet();

        System.out.println();
        System.out.println("======================================");
        System.out.println("검색 요청 번호 = #" + requestNumber);
        System.out.println("Controller 전달값 = [" + name + "]");

        List<ResidentResponse> result;

        if (name == null) {
            System.out.println("전달된 검색어가 null입니다.");
            System.out.println("빈 목록을 반환합니다.");

            result = List.of();

        } else {

            System.out.println("원본 검색어 길이 = " + name.length());

            String keyword = name.trim();

            System.out.println("공백 제거 검색어 = [" + keyword + "]");
            System.out.println("공백 제거 후 길이 = " + keyword.length());

            if (keyword.isEmpty()) {
                System.out.println("검색어가 비어 있습니다.");
                System.out.println("빈 목록을 반환합니다.");

                result = List.of();

            } else {

                System.out.println(
                        "ResidentService에 전달하는 검색어 = ["
                                + keyword
                                + "]"
                );

                result = residentService.searchResidents(keyword);
            }
        }

        System.out.println(
                "Controller 최종 반환 개수 = "
                        + result.size()
        );

        System.out.println(
                "검색 요청 #"
                        + requestNumber
                        + " 종료"
        );

        System.out.println("======================================");

        return new ApiResponse<>(
                true,
                "주민 검색 성공",
                result
        );
    }

    // 주민 한 명 조회
    @GetMapping("/{id}")
    public ApiResponse<ResidentResponse> getResident(
            @PathVariable Long id) {

        ResidentResponse resident =
                residentService.getResident(id);

        return new ApiResponse<>(
                true,
                "주민 조회 성공",
                resident
        );
    }

    // 주민 정보 수정
    @PutMapping("/{id}")
    public ApiResponse<ResidentResponse> updateResident(
            @PathVariable Long id,
            @Valid @RequestBody ResidentUpdateRequest request) {

        ResidentResponse resident =
                residentService.updateResident(id, request);

        return new ApiResponse<>(
                true,
                "주민 정보 수정 성공",
                resident
        );
    }

    // 주민 삭제
    @DeleteMapping("/{id}")
    public ApiResponse<Void> deleteResident(
            @PathVariable Long id) {

        residentService.deleteResident(id);

        return new ApiResponse<>(
                true,
                "주민 삭제 성공",
                null
        );
    }
}