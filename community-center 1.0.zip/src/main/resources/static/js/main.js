// ========================================
// 메인 홈페이지 JavaScript
// ========================================


// ========================================
// DOM 요소
// ========================================

const header = document.querySelector("header");

const navigationLinks =
    document.querySelectorAll('nav a[href^="#"]');

const topButton =
    document.querySelector("#top-button");

const sections =
    document.querySelectorAll("main section[id]");

const noticeItems =
    document.querySelectorAll(".notice-item");

const noticeToggleButton =
    document.querySelector("#notice-toggle-button");

let isNoticeExpanded = false;


// ========================================
// 공지사항 표시 상태
// ========================================

function updateNoticeList() {

    noticeItems.forEach((item, index) => {

        if (!isNoticeExpanded && index >= 4) {

            item.style.display = "none";

        } else {

            item.style.display = "flex";

        }

    });

}

// ========================================
// 현재 메뉴 활성화
// ========================================

function updateActiveNavigation() {

    let currentSectionId = "";

    sections.forEach((section) => {

        const sectionTop = section.offsetTop;
        const sectionHeight = section.offsetHeight;

        if (
            window.scrollY >= sectionTop - 150 &&
            window.scrollY < sectionTop + sectionHeight - 150
        ) {
            currentSectionId = section.id;
        }

    });

    navigationLinks.forEach((link) => {

        const targetId =
            link.getAttribute("href");

        if (targetId === `#${currentSectionId}`) {

            link.classList.add("active");

        } else {

            link.classList.remove("active");

        }

    });

}


// ========================================
// 페이지 내부 메뉴 이동
// ========================================

navigationLinks.forEach((link) => {

    link.addEventListener("click", (event) => {

        const targetId =
            link.getAttribute("href");

        const target =
            document.querySelector(targetId);

        if (!target) {
            return;
        }

        event.preventDefault();

        target.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });

    });

});


// ========================================
// 스크롤 Header 효과
// ========================================

window.addEventListener("scroll", () => {

    // Header 효과
    if (window.scrollY > 50) {

        header.classList.add("scrolled");

    } else {

        header.classList.remove("scrolled");

    }


    // 맨 위로 이동 버튼 표시
    if (window.scrollY > 300) {

        topButton.classList.add("show");

    } else {

        topButton.classList.remove("show");

    }


    // 현재 보고 있는 메뉴 활성화
    updateActiveNavigation();

});


// ========================================
// 맨 위로 이동 버튼
// ========================================

topButton.addEventListener("click", () => {

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

});


// ========================================
// 공지사항 더보기 / 접기
// ========================================

noticeToggleButton.addEventListener("click", () => {

    isNoticeExpanded = !isNoticeExpanded;

    updateNoticeList();

    if (isNoticeExpanded) {

        noticeToggleButton.textContent = "공지사항 접기";

    } else {

        noticeToggleButton.textContent = "공지사항 더보기";

    }

});



// ========================================
// 페이지 시작
// ========================================

updateNoticeList();

console.log("주민센터 메인 홈페이지가 실행되었습니다.");