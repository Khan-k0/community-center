const residentList = document.querySelector("#resident-list");
const residentForm = document.querySelector("#resident-form");
const formMessage = document.querySelector("#form-message");

const submitButton =
    document.querySelector("#submit-button");

const cancelEditButton =
    document.querySelector("#cancel-edit-button");

const sortBySelect = document.querySelector("#sort-by");
const sortDirectionSelect = document.querySelector("#sort-direction");
const sortButton = document.querySelector("#sort-button");

const searchName = document.querySelector("#search-name");
const searchButton = document.querySelector("#search-button");
const resetSearchButton =
    document.querySelector("#reset-search-button");

const prevButton = document.querySelector("#prev-button");
const nextButton = document.querySelector("#next-button");
const pageInfo = document.querySelector("#page-info");
const residentCount = document.querySelector("#resident-count");
const pageSizeSelect = document.querySelector("#page-size");

// ==============================
// 상태값
// ==============================

// 수정 중인 주민 ID
let editingResidentId = null;

// 현재 페이지
let currentPage = 0;

// 한 페이지당 주민 수
let pageSize = 5;

// 전체 페이지 수
let totalPages = 0;

// 현재 검색어
let currentKeyword = "";

// 정렬 기준
let currentSortBy = "id";

// 정렬 방향
let currentDirection = "asc";




// ==============================
// 페이지당 표시 개수 변경
// ==============================

pageSizeSelect.addEventListener("change", async () => {

    // 선택한 값을 숫자로 변환
    pageSize = Number(pageSizeSelect.value);

    // 표시 개수가 변경되면 첫 페이지로 이동
    currentPage = 0;

    // 주민 목록 다시 불러오기
    await loadResidentList();

});


// ==============================
// 정렬
// ==============================
sortButton.addEventListener("click", async () => {

    currentSortBy = sortBySelect.value;
    currentDirection = sortDirectionSelect.value;

    // 정렬 기준이 바뀌면 첫 페이지로 이동
    currentPage = 0;

    await loadResidentList();
});



// ==============================
// HTML 특수문자 변환
// ==============================

function escapeHtml(value) {

    if (value === null || value === undefined) {
        return "";
    }

    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}



// ==============================
// 통합 주민 조회
// 검색 + 페이징 + 정렬
// ==============================
async function loadResidentList() {

    try {

        const params = new URLSearchParams({
            page: currentPage,
            size: pageSize,
            sortBy: currentSortBy,
            direction: currentDirection
        });

        // 검색어가 있을 때만 name 파라미터 추가
        if (currentKeyword !== "") {
            params.append("name", currentKeyword);
        }

        const response = await fetch(
            `/api/residents/list?${params.toString()}`
        );

        if (!response.ok) {
            throw new Error(
                "주민 목록 조회에 실패했습니다."
            );
        }

        const result = await response.json();

		const pageData = result.data;

		renderResidents(pageData.content);

		totalPages = pageData.totalPages;

		// 주민 수 표시
		if (currentKeyword !== "") {
		    residentCount.textContent =
		        `검색 결과: ${pageData.totalElements}명`;
		} else {
		    residentCount.textContent =
		        `전체 주민 수: ${pageData.totalElements}명`;
		}

        // 삭제 등으로 현재 페이지가 사라진 경우
        if (
            totalPages > 0 &&
            currentPage >= totalPages
        ) {
            currentPage = totalPages - 1;

            await loadResidentList();

            return;
        }

        updatePagination();

    } catch (error) {

        console.error(error);

        residentList.innerHTML = `
            <tr>
                <td colspan="7">
                    주민 목록을 불러오지 못했습니다.
                </td>
            </tr>
        `;
    }
}


// ==============================
// 주민 목록 화면 출력
// ==============================
function renderResidents(residents) {

    if (!residents || residents.length === 0) {

        const emptyMessage =
            currentKeyword !== ""
                ? "검색 결과가 없습니다."
                : "등록된 주민이 없습니다.";

        residentList.innerHTML = `
	        <tr>
	            <td colspan="7">
	                ${emptyMessage}
	            </td>
	        </tr>
	    `;

        return;
    }

    residentList.innerHTML = residents
        .map((resident) => `
	        <tr>
	            <td>${resident.id}</td>
	            <td>${escapeHtml(resident.name)}</td>
	            <td>${escapeHtml(resident.phone)}</td>
	            <td>${escapeHtml(resident.address)}</td>
	            <td>${formatDate(resident.createdAt)}</td>
	            <td>${formatDate(resident.updatedAt)}</td>
                <td>
                    <button
                        type="button"
                        onclick="editResident(${resident.id})">
                        수정
                    </button>

                    <button
                        type="button"
                        onclick="deleteResident(${resident.id})">
                        삭제
                    </button>
                </td>
            </tr>
        `)
        .join("");
}


// ==============================
// 날짜 표시
// ==============================
function formatDate(dateTime) {

    if (!dateTime) {
        return "-";
    }

    return new Date(dateTime)
        .toLocaleString("ko-KR");
}


// ==============================
// 페이징 화면 갱신
// ==============================
function updatePagination() {

    if (totalPages === 0) {

        pageInfo.textContent = "0 / 0";

        prevButton.disabled = true;
        nextButton.disabled = true;

        return;
    }

    pageInfo.textContent =
        `${currentPage + 1} / ${totalPages}`;

    prevButton.disabled =
        currentPage === 0;

    nextButton.disabled =
        currentPage >= totalPages - 1;
}


// ==============================
// 검색
// ==============================
async function searchResidents() {

    currentKeyword =
        searchName.value.trim();

    // 검색을 새로 시작하면 첫 페이지로 이동
    currentPage = 0;

    await loadResidentList();
}


// ==============================
// 검색 버튼
// ==============================
searchButton.addEventListener(
    "click",
    async () => {

        await searchResidents();
    }
);


// ==============================
// 검색창 Enter
// ==============================
searchName.addEventListener(
    "keydown",
    async (event) => {

        if (event.key === "Enter") {

            event.preventDefault();

            await searchResidents();
        }
    }
);


// ==============================
// 전체보기
// ==============================
resetSearchButton.addEventListener(
    "click",
    async () => {

        searchName.value = "";

        currentKeyword = "";

        currentPage = 0;

        await loadResidentList();
    }
);


// ==============================
// 이전 페이지
// ==============================
prevButton.addEventListener(
    "click",
    async () => {

        if (currentPage > 0) {

            currentPage--;

            await loadResidentList();
        }
    }
);


// ==============================
// 다음 페이지
// ==============================
nextButton.addEventListener(
    "click",
    async () => {

        if (
            currentPage <
            totalPages - 1
        ) {

            currentPage++;

            await loadResidentList();
        }
    }
);


// ==============================
// 주민 등록 / 수정
// ==============================
residentForm.addEventListener(
    "submit",
    async (event) => {

        event.preventDefault();

        const name =
            document
                .querySelector("#name")
                .value
                .trim();

        const phone =
            document
                .querySelector("#phone")
                .value
                .trim();

        const address =
            document
                .querySelector("#address")
                .value
                .trim();

        const resident = {
            name,
            phone,
            address
        };

        try {

            let url = "/api/residents";
            let method = "POST";

            // 수정 중일 경우 PUT
            if (editingResidentId !== null) {

                url =
                    `/api/residents/${editingResidentId}`;

                method = "PUT";
            }

            const response =
                await fetch(url, {

                    method: method,

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body:
                        JSON.stringify(resident)
                });

            const result =
                await response.json();

            if (!response.ok) {

                throw new Error(
                    result.message ||
                    "주민 정보 저장에 실패했습니다."
                );
            }

            formMessage.textContent =
                result.message;

            residentForm.reset();

            editingResidentId = null;

            submitButton.textContent = "주민 등록";
            cancelEditButton.hidden = true;

            // 등록 후 첫 페이지로 이동
            // 수정은 현재 페이지 유지
            if (method === "POST") {
                currentPage = 0;
            }

            await loadResidentList();

        } catch (error) {

            console.error(error);

            formMessage.textContent =
                error.message;
        }
    }
);


// ==============================
// 주민 수정 준비
// ==============================
async function editResident(id) {

    try {

        const response =
            await fetch(
                `/api/residents/${id}`
            );

        const result =
            await response.json();

        if (!response.ok) {

            throw new Error(
                result.message ||
                "주민 정보를 불러오지 못했습니다."
            );
        }

        const resident =
            result.data;

        editingResidentId = id;

        document
            .querySelector("#name")
            .value =
            resident.name;

        document
            .querySelector("#phone")
            .value =
            resident.phone;

        document
            .querySelector("#address")
            .value =
            resident.address;

        submitButton.textContent = "주민 수정";
        cancelEditButton.hidden = false;

        formMessage.textContent =
            `${resident.name} 주민 정보를 수정 중입니다.`;

    } catch (error) {

        console.error(error);

        alert(error.message);
    }
}


// ========================================
// 수정 취소
// ========================================

cancelEditButton.addEventListener("click", () => {

    editingResidentId = null;

    residentForm.reset();

    submitButton.textContent = "주민 등록";

    cancelEditButton.hidden = true;

    formMessage.textContent = "";

});


// ==============================
// 주민 삭제
// ==============================
async function deleteResident(id) {

    const confirmed =
        confirm(
            "정말 이 주민을 삭제하시겠습니까?"
        );

    if (!confirmed) {
        return;
    }

    try {

        const response =
            await fetch(
                `/api/residents/${id}`,
                {
                    method: "DELETE"
                }
            );

        const result =
            await response.json();

        if (!response.ok) {

            throw new Error(
                result.message ||
                "주민 삭제에 실패했습니다."
            );
        }

        alert(result.message);

        // 삭제 대상이 수정 중이었던 주민이면 초기화
        if (editingResidentId === id) {

            editingResidentId = null;

            residentForm.reset();

            submitButton.textContent = "주민 등록";
            cancelEditButton.hidden = true;

            formMessage.textContent = "";
        }

        // 현재 검색/페이지 상태 유지하면서 다시 조회
        await loadResidentList();

    } catch (error) {

        console.error(error);

        alert(error.message);
    }
}


// ==============================
// 페이지 최초 실행
// ==============================
loadResidentList();